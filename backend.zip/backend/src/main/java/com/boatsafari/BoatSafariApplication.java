package com.boatsafari;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoatSafariApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoatSafariApplication.class, args);
	}

}
