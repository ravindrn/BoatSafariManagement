package com.boatsafari;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoatSafariApplicationTests {

	@Test
	void contextLoads() {
	}

}
