// src/main/java/com/boatsafari/model/ReviewStatus.java
package com.boatsafari.model;

public enum ReviewStatus {
    PENDING,
    APPROVED,
    REJECTED
}