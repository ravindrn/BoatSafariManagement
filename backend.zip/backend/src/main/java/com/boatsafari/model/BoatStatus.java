package com.boatsafari.model;

public enum BoatStatus {
    AVAILABLE,
    MAINTENANCE,
    IN_USE,
    INACTIVE
}