package com.boatsafari.model;

public enum UserRole {
    SYSTEM_ADMINISTRATOR,
    CUSTOMER,
    STAFF,
    USER_MANAGER,
    BOAT_OWNER,
    OPERATIONS_MANAGER
}